### Chapter 4 -- Flowering Stone: The Taste for India and the Islamic World

![Image of Hindustan jade](https://images.metmuseum.org/CRDImages/as/original/DP108021.jpg)
##### Flower-Shaped Bowl. 17th-18th century, Qianlong mark and period. Jade (nephrite), H. 2 1/16 in. (5.2 cm); W. 7 5/16 in. (18.6 cm); D. 4 1/4 in. (10.8 cm). Metropolitan Museum of Art. 50.145.113.

![Detail image of poem incised on Hindustan jade](https://images.metmuseum.org/CRDImages/as/original/DP108022.jpg)

Complete text of poem:

痕都斯坦菊花椀

径一圍三尺有餘

水磨工異考工書

耳垂翻出雙苞綴

足砥紛承碎瓣舒

包貢却非来玉隴

通商恆是走渠胥

菊花依舊重陽節

合贈淵明五柳居

乾隆庚寅御题

[square seal] 比德
