#### Useful resources:

* [National Palace Museum (Taipei)](https://www.npm.gov.tw/en/)
  * [Zoom in on a inscribed jade plate with gold tracery and red stones](https://theme.npm.edu.tw/selection/Article.aspx?sNo=04001081&lang=2)
  * [Exquisite Beauty: Islamic Jades](https://www.npm.gov.tw/exh96/islamicjade/intro_en.htm)
  * [Explore items from the Qing dynasty](https://theme.npm.edu.tw/selection/dynasty.aspx?idx=3&lang=2)
  * [Open Data](https://theme.npm.edu.tw/opendata/?lang=2)
