> _**"Such offerings come to us not only as tribute from the Yulong River in Khotan, but also are brought back by merchants from distant India."**_
 
 --**"_On a Hindustan Jade Chrysanthemum Bowl_" (Qianlong emperor, incised poem dated 1770 but published 1771)**  
