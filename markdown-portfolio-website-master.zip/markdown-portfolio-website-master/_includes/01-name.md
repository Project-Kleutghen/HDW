# Kristina Kleutghen

## Humanities Digital Workshop

### The Local Exotic: Fabricating Foreign Taste in High Qing Court Decorative Arts
